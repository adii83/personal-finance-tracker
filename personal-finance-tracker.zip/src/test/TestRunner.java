package test;

import test.manager.FinanceReportTest;

public class TestRunner {
    public static void main(String[] args) {
        System.out.println("Starting Unit Tests...\n");
        
        try {
            FinanceReportTest.runTests();
            System.out.println("\nAll tests finished successfully.");
        } catch (AssertionError e) {
            System.err.println("\nTest execution halted due to failure: " + e.getMessage());
            System.exit(1);
        } catch (Exception e) {
            System.err.println("\nUnexpected error during test execution: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}
