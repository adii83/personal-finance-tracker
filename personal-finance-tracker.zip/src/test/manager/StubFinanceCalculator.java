package test.manager;

import java.util.ArrayList;
import manager.FinanceCalculator;
import model.Transaction;

public class StubFinanceCalculator extends FinanceCalculator {
    private final double income;
    private final double expense;
    private final double balance;

    public StubFinanceCalculator(double income, double expense, double balance) {
        this.income = income;
        this.expense = expense;
        this.balance = balance;
    }

    @Override
    public double calculateTotalIncome(ArrayList<Transaction> transactions) {
        return income;
    }

    @Override
    public double calculateTotalExpense(ArrayList<Transaction> transactions) {
        return expense;
    }

    @Override
    public double calculateBalance(ArrayList<Transaction> transactions) {
        return balance;
    }
}
