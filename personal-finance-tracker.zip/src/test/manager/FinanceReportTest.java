package test.manager;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import manager.FinanceReport;
import model.Transaction;

public class FinanceReportTest {

    public static void runTests() {
        testShowReport_KeuanganAman();
        testShowReport_PengeluaranLebihBesar();
    }

    private static void testShowReport_KeuanganAman() {
        StubFinanceCalculator stubCalculator = new StubFinanceCalculator(1000000, 250000, 750000);
        FinanceReport report = new FinanceReport(stubCalculator);
        ArrayList<Transaction> dummyTransactions = new ArrayList<>();

        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outContent));

        try {
            report.showReport(dummyTransactions);
            String output = outContent.toString();
            
            if (!output.contains("Total Pemasukan   : Rp1000000.0")) throw new AssertionError("Pemasukan salah");
            if (!output.contains("Total Pengeluaran : Rp250000.0")) throw new AssertionError("Pengeluaran salah");
            if (!output.contains("Saldo Akhir       : Rp750000.0")) throw new AssertionError("Saldo salah");
            if (!output.contains("Status            : Keuangan masih aman.")) throw new AssertionError("Status salah");
            
            System.setOut(originalOut);
            System.out.println("FinanceReportTest.testShowReport_KeuanganAman           PASSED");
        } catch (Exception e) {
            System.setOut(originalOut);
            System.out.println("FinanceReportTest.testShowReport_KeuanganAman           FAILED");
            throw e;
        }
    }

    private static void testShowReport_PengeluaranLebihBesar() {
        StubFinanceCalculator stubCalculator = new StubFinanceCalculator(500000, 800000, -300000);
        FinanceReport report = new FinanceReport(stubCalculator);
        ArrayList<Transaction> dummyTransactions = new ArrayList<>();

        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outContent));

        try {
            report.showReport(dummyTransactions);
            String output = outContent.toString();
            
            if (!output.contains("Total Pemasukan   : Rp500000.0")) throw new AssertionError("Pemasukan salah");
            if (!output.contains("Total Pengeluaran : Rp800000.0")) throw new AssertionError("Pengeluaran salah");
            if (!output.contains("Saldo Akhir       : Rp-300000.0")) throw new AssertionError("Saldo salah");
            if (!output.contains("Status            : Pengeluaran lebih besar dari pemasukan.")) throw new AssertionError("Status salah");
            
            System.setOut(originalOut);
            System.out.println("FinanceReportTest.testShowReport_PengeluaranLebihBesar  PASSED");
        } catch (Exception e) {
            System.setOut(originalOut);
            System.out.println("FinanceReportTest.testShowReport_PengeluaranLebihBesar  FAILED");
            throw e;
        }
    }
}
